README.txt
Muhammad Daffa Rahman
L0124062

Untuk mengcompile main dapat menggunakan perintah "make main"
Untuk mengcompile test dapat menggunakan perintah "make test"